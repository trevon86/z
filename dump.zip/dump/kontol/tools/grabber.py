import requests
import random
import re
import os
import string
import sys
from multiprocessing.dummy import Pool as ThreadPool

def random_bitch():
    randoms = random.choice(["@", "#", "$", "?", "!"])
    return randoms

def grabber(domain, page, file, source):
    if source == "topsitessearch":
        list_url = TopSite(domain, page)
        pool = ThreadPool(20)
        pool.map(lambda url: GrabTopSite(url, file), list_url)
    elif source == "pagesinventory":
        list_url = PagesSite(domain)
        pool = ThreadPool(20)
        pool.map(lambda url: GrabPages(url, file), list_url)
    elif source == "azstats":
        list_url = AzstatSite(domain, page)
        pool = ThreadPool(20)
        pool.map(lambda url: GrabAzstat(url, file), list_url)
    elif source == "asusite":
        list_url = AsuSiteGen(domain, page)
        pool = ThreadPool(20)
        pool.map(lambda url: AsuSite(url, file), list_url)
    pool.close()
    pool.join()
    
def AsuSiteGen(domain, page):
  arr = []
  for i in range(1, page + 1):
    arr.append(f'https://website.informer.com/search.php?query={domain}')
  return arr
  
def AsuSite(url, file):
    try:
        page = url.split("/")[-1]
        req = requests.get(url, timeout=10)
        domains = re.findall('data-domain="(.*)"', req.text)
        
        if len(domains) == 0:
            print(f"[{random_bitch()}] Total Domain > 0")
        else:
            print(f"[{random_bitch()}] {len(domains)} Total Domain > {len(page)}")
            with open(f"Result/{file}", "a") as f:
                for domain in domains:
                    f.write(domain + "\n")
    except:
        print(f"[{random_bitch()}] Total Domain > 0")
        

def TopSite(tld, totalPage):
    arr = []
    for i in range(1, totalPage + 1):
        arr.append(f"https://www.topsitessearch.com/domains/.{tld}/{i}")
    return arr

def GrabTopSite(url, file):
    try:
        page = url.split("/")[-1]
        req = requests.get(url, timeout=10)
        domains = re.findall(r'domain=(.*?)"', req.text)
        
        if len(domains) == 0:
            print(f"[{random_bitch()}] Total Domain > 0")
        else:
            print(f"[{random_bitch()}] {len(domains)} Total Domain > {page}")
            with open(f"Result/{file}", "a") as f:
                for domain in domains:
                    f.write(domain + "\n")
    except:
        print(f"[{random_bitch()}] Total Domain > 0")

def PagesSite(tld):
    arr = []
    for x in string.ascii_lowercase:
        arr.append(f"https://www.pagesinventory.com/tld/{tld}/{x}.html")
    return arr

def GrabPages(url, file):
    try:
        page = url.split("/")[-1]
        req = requests.get(url, timeout=5)
        domains = re.findall(r'href="/domain/(.*?).html"', req.text)
        
        if len(domains) == 0:
            print(f"[{random_bitch()}] Total Domain > 0")
        else:
            print(f"[{random_bitch()}] {len(domains)} Total Domain > {page}")
            with open(f"Result/{file}", "a") as f:
                for domain in domains:
                    f.write(domain + "\n")
    except:
        print(f"[{random_bitch()}] Total Domain > 0")
        
def AzstatSite(tld, page):
    arr = []
    for x in range(1, page + 1):
        arr.append(f"https://azstats.org/top/domain-zone/{tld}/{x}")
    return arr
        
def GrabAzstat(url, file):
    try:
        page = url.split("/")[-1]
        req = requests.get(url, timeout=5)
        domains = re.findall(r'href="/site/(.*?)/"', req.text)
        
        if len(domains) == 0:
            print(f"[{random_bitch()}] Total Domain > 0")
        else:
            print(f"[{random_bitch()}] {len(domains)} Total Domain > {page}")
            with open(f"Result/{file}", "a") as f:
                for domain in domains:
                    f.write(domain + "\n")
    except:
        print(f"[{random_bitch()}] Total Domain > 0")