import os, sys
from tools.grabber import grabber
from tools.reverse import reverse

def Folder(directory):
  if not os.path.exists(directory):
    os.makedirs(directory)
Folder('Result')

def banner():
  banner = """
Jxdn Ganteng
  [1] Grabber Domains
  [2] Reverse Domains
Telegram @damnnn67
  """
  return banner
  
def Main():
  print(banner())
  options = int(input("Options > "))
  if options == 1:
    domain = str(input("Domains (ex: go.id) > "))
    page = int(input("Page (ex: 100) > "))
    file = str(input("Savefile (ex: output.txt) > "))
    grabber(domain, page, file, "topsitessearch")
    grabber(domain, page, file, "pagesinventory")
    grabber(domain, page, file, "azstats")
    grabber(domain, page, file, "asusite")
  elif options == 2:
    domain_list = open(input("Domain list > "), "r").read().replace("https://", "").replace("http://", "").replace("/", "")
    remove = str(input("Remove List > "))
    file = str(input("Savefile (ex: output.txt > "))
    reverse(domain_list, remove, file)
  else:
    exit("Asu")
    
if __name__ == "__main__":
  Main()