import socket
import requests
import random
import json
import threading
import time
import os
from bs4 import BeautifulSoup as sp
from multiprocessing.dummy import Pool
from urllib.request import urlopen

def random_bitch():
    randoms = random.choice(["@","#","$","?","!"])
    return randoms

def API(ip, file):
    try:
        url = "https://otx.alienvault.com/otxapi/indicator/ip/passive_dns/" + ip
        response = urlopen(url)
        data = json.loads(response.read())["passive_dns"]
        print(f"[{random_bitch()}] Reversing {ip} > {len(data)} Domains")
        with open(f"Result/{file}", "a") as f:
            for dom in data:
                f.write(dom["hostname"] + "\n")
    except Exception as e:
        print(f"Error [{ip}]: {e}")
        time.sleep(0.5)

def reverse(lst, s, sv):
    iplist = []
    with open(s, "w") as f:
        f.write(lst)
    
    with open(s, "r") as f:
        hostnames = f.read().splitlines()
    
    for hostname in hostnames:
        try:
            ip = socket.gethostbyname(hostname)
        except socket.gaierror:
            print(f"Failed to resolve {hostname}")
            ip = "None"
        
        if ip != "None" and ip not in iplist:
            iplist.append(ip)
            API(ip, sv)